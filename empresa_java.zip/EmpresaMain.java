import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EmpresaMain {
    private static List<Empresa> empresas = new ArrayList<>();
    private static List<Funcionario> funcionarios = new ArrayList<>();
    private static List<Associado> associados = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao;

        do {
            System.out.println("=== SISTEMA DE EMPRESAS ===");
            System.out.println("1 - Cadastrar empresa");
            System.out.println("2 - Cadastrar funcionário");
            System.out.println("3 - Cadastrar associado");
            System.out.println("4 - Listar tudo");
            System.out.println("5 - Salvar em arquivo TXT");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1 -> cadastrarEmpresa();
                case 2 -> cadastrarFuncionario();
                case 3 -> cadastrarAssociado();
                case 4 -> listarTudo();
                case 5 -> salvarArquivo();
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Opção inválida!");
            }
            System.out.println();
        } while (opcao != 0);
    }

    private static void cadastrarEmpresa() {
        System.out.print("Nome da empresa: ");
        String nome = sc.nextLine();
        System.out.print("CNPJ: ");
        String cnpj = sc.nextLine();
        System.out.print("Endereço: ");
        String endereco = sc.nextLine();
        empresas.add(new Empresa(nome, cnpj, endereco));
        System.out.println("Empresa cadastrada!");
    }

    private static void cadastrarFuncionario() {
        System.out.print("Nome do funcionário: ");
        String nome = sc.nextLine();
        System.out.print("Cargo: ");
        String cargo = sc.nextLine();
        System.out.print("Salário: ");
        double salario = sc.nextDouble();
        sc.nextLine();
        funcionarios.add(new Funcionario(nome, cargo, salario));
        System.out.println("Funcionário cadastrado!");
    }

    private static void cadastrarAssociado() {
        System.out.print("Nome do associado: ");
        String nome = sc.nextLine();
        System.out.print("Cargo: ");
        String cargo = sc.nextLine();
        System.out.print("Salário: ");
        double salario = sc.nextDouble();
        sc.nextLine();
        System.out.print("Tipo de associação: ");
        String tipo = sc.nextLine();
        associados.add(new Associado(nome, cargo, salario, tipo));
        System.out.println("Associado cadastrado!");
    }

    private static void listarTudo() {
        System.out.println("\n=== EMPRESAS ===");
        empresas.forEach(System.out::println);

        System.out.println("=== FUNCIONÁRIOS ===");
        funcionarios.forEach(System.out::println);

        System.out.println("=== ASSOCIADOS ===");
        associados.forEach(System.out::println);
    }

    private static void salvarArquivo() {
        System.out.print("Nome do arquivo (sem .txt): ");
        String nomeArquivo = sc.nextLine();

        try (FileWriter writer = new FileWriter(nomeArquivo + ".txt")) {
            writer.write("=== EMPRESAS ===\n");
            for (Empresa e : empresas) writer.write(e + "\n");

            writer.write("=== FUNCIONÁRIOS ===\n");
            for (Funcionario f : funcionarios) writer.write(f + "\n");

            writer.write("=== ASSOCIADOS ===\n");
            for (Associado a : associados) writer.write(a + "\n");

            System.out.println("Arquivo salvo com sucesso: " + nomeArquivo + ".txt");
        } catch (IOException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        }
    }
}