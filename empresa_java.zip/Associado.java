public class Associado extends Funcionario {
    private String tipoAssociacao;

    public Associado(String nome, String cargo, double salario, String tipoAssociacao) {
        super(nome, cargo, salario);
        this.tipoAssociacao = tipoAssociacao;
    }

    public String getTipoAssociacao() { return tipoAssociacao; }

    @Override
    public String toString() {
        return "Associado: " + getNome() + 
               " | Cargo: " + getCargo() + 
               " | Salário: R$" + getSalario() +
               " | Tipo: " + tipoAssociacao;
    }
}