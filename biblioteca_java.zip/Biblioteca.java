import java.util.*;
import java.io.*;

public class Biblioteca {
    private List<Publicacao> publicacoes = new ArrayList<>();
    private Map<String, Publicacao> mapaPublicacoes = new HashMap<>();

    public void adicionarPublicacao(Publicacao p) {
        publicacoes.add(p);
        mapaPublicacoes.put(p.getTitulo(), p);
    }

    public Publicacao buscarPorTitulo(String titulo) {
        return mapaPublicacoes.get(titulo);
    }

    public boolean emprestar(String titulo) {
        Publicacao p = mapaPublicacoes.get(titulo);
        if (p != null && p.isDisponivel()) {
            p.setDisponivel(false);
            return true;
        }
        return false;
    }

    public void salvarEmArquivo(String nomeArquivo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(nomeArquivo))) {
            for (Publicacao p : publicacoes) {
                writer.println(p.detalhes() + " | Disponível: " + p.isDisponivel());
            }
            System.out.println("Dados salvos com sucesso!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void listarPublicacoes() {
        for (Publicacao p : publicacoes) {
            System.out.println(p.detalhes() + " | Disponível: " + p.isDisponivel());
        }
    }
}