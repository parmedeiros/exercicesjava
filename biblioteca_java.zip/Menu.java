import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();

        Autor autor1 = new Autor("Machado de Assis", "Brasileiro");
        Autor autor2 = new Autor("Stephen King", "Americano");

        biblioteca.adicionarPublicacao(new Livro("Dom Casmurro", autor1, 1899, 256));
        biblioteca.adicionarPublicacao(new Revista("Tech Today", autor2, 2022, 45));

        int opcao;
        do {
            System.out.println("\n--- MENU BIBLIOTECA ---");
            System.out.println("1. Listar publicações");
            System.out.println("2. Buscar por título");
            System.out.println("3. Emprestar publicação");
            System.out.println("4. Salvar em arquivo");
            System.out.println("0. Sair");
            System.out.print("Opção: ");
            opcao = sc.nextInt(); sc.nextLine();

            switch (opcao) {
                case 1 -> biblioteca.listarPublicacoes();
                case 2 -> {
                    System.out.print("Título: ");
                    String titulo = sc.nextLine();
                    Publicacao p = biblioteca.buscarPorTitulo(titulo);
                    System.out.println(p != null ? p.detalhes() : "Não encontrada.");
                }
                case 3 -> {
                    System.out.print("Título para empréstimo: ");
                    String titulo = sc.nextLine();
                    System.out.println(biblioteca.emprestar(titulo)
                        ? "Empréstimo realizado!" : "Não disponível ou não encontrada.");
                }
                case 4 -> biblioteca.salvarEmArquivo("publicacoes.txt");
            }
        } while (opcao != 0);
        sc.close();
    }
}