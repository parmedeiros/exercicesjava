public class Revista extends Publicacao {
    private int edicao;

    public Revista(String titulo, Autor autor, int anoPublicacao, int edicao) {
        super(titulo, autor, anoPublicacao);
        this.edicao = edicao;
    }

    public int getEdicao() { return edicao; }
    public void setEdicao(int edicao) { this.edicao = edicao; }

    @Override
    public String detalhes() {
        return super.detalhes() + ", Edição: " + edicao;
    }
}