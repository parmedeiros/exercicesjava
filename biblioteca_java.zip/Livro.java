public class Livro extends Publicacao {
    private int numeroPaginas;

    public Livro(String titulo, Autor autor, int anoPublicacao, int numeroPaginas) {
        super(titulo, autor, anoPublicacao);
        this.numeroPaginas = numeroPaginas;
    }

    public int getNumeroPaginas() { return numeroPaginas; }
    public void setNumeroPaginas(int numeroPaginas) { this.numeroPaginas = numeroPaginas; }

    @Override
    public String detalhes() {
        return super.detalhes() + ", Páginas: " + numeroPaginas;
    }
}