public class Carro {
    String modelo;
    String cor;
    int ano;

    public Carro() {}

    public Carro(String modelo, String cor, int ano) {
        this.modelo = modelo;
        this.cor = cor;
        this.ano = ano;
    }

    public String detalhes() {
        return "Carro: " + modelo + " | Cor: " + cor + " | Ano: " + ano;
    }
}
