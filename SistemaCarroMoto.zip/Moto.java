public class Moto {
    String modelo;
    String cor;
    int cilindradas;

    public Moto() {}

    public Moto(String modelo, String cor, int cilindradas) {
        this.modelo = modelo;
        this.cor = cor;
        this.cilindradas = cilindradas;
    }

    public String detalhes() {
        return "Moto: " + modelo + " | Cor: " + cor + " | " + cilindradas + "cc";
    }
}
