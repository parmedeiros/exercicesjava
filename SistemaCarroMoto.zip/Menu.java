import java.util.*;

public class Menu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Carro> carros = new ArrayList<>();
        List<Moto> motos = new ArrayList<>();
        int opcao;

        do {
            System.out.println("\n--- MENU VEÍCULOS ---");
            System.out.println("1 - Cadastrar Carro");
            System.out.println("2 - Cadastrar Moto");
            System.out.println("3 - Listar Carros");
            System.out.println("4 - Listar Motos");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Modelo: ");
                    String modeloC = sc.nextLine();
                    System.out.print("Cor: ");
                    String corC = sc.nextLine();
                    System.out.print("Ano: ");
                    int ano = sc.nextInt(); sc.nextLine();
                    carros.add(new Carro(modeloC, corC, ano));
                    System.out.println("Carro cadastrado!");
                    break;

                case 2:
                    System.out.print("Modelo: ");
                    String modeloM = sc.nextLine();
                    System.out.print("Cor: ");
                    String corM = sc.nextLine();
                    System.out.print("Cilindradas: ");
                    int cc = sc.nextInt(); sc.nextLine();
                    motos.add(new Moto(modeloM, corM, cc));
                    System.out.println("Moto cadastrada!");
                    break;

                case 3:
                    System.out.println("\n--- Lista de Carros ---");
                    for (Carro c : carros) System.out.println(c.detalhes());
                    break;

                case 4:
                    System.out.println("\n--- Lista de Motos ---");
                    for (Moto m : motos) System.out.println(m.detalhes());
                    break;
            }
        } while (opcao != 0);

        sc.close();
        System.out.println("Encerrando o sistema...");
    }
}
